var searchData=
[
  ['plansza_2ecpp_0',['plansza.cpp',['../plansza_8cpp.html',1,'']]]
];
