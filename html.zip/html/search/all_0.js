var searchData=
[
  ['board_2eh_0',['board.h',['../board_8h.html',1,'']]],
  ['board_5fsize_1',['BOARD_SIZE',['../c_09_09_8cpp.html#aa7a2b8ea2c784a4ad8b58a3262bb4f07',1,'c++.cpp']]]
];
