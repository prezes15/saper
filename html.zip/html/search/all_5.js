var searchData=
[
  ['performmove_0',['performMove',['../c_09_09_8cpp.html#a027eaa367d014a475aa34acd2434147c',1,'c++.cpp']]],
  ['plansza_2ecpp_1',['plansza.cpp',['../plansza_8cpp.html',1,'']]]
];
