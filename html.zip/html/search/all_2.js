var searchData=
[
  ['deleteboard_0',['deleteBoard',['../board_8h.html#ae91dd3ac3ca6c145fbdbcf82eab748f6',1,'deleteBoard(char **board, int size):&#160;plansza.cpp'],['../plansza_8cpp.html#ae91dd3ac3ca6c145fbdbcf82eab748f6',1,'deleteBoard(char **board, int size):&#160;plansza.cpp']]],
  ['display_2eh_1',['display.h',['../display_8h.html',1,'']]],
  ['displayboard_2',['displayBoard',['../display_8h.html#a335d55e76dd4c2dbe29a36dc292e2915',1,'displayBoard(char **board, int size):&#160;wyswietlanie.cpp'],['../wyswietlanie_8cpp.html#a335d55e76dd4c2dbe29a36dc292e2915',1,'displayBoard(char **board, int size):&#160;wyswietlanie.cpp']]]
];
