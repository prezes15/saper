var plansza_8cpp =
[
    [ "createBoard", "plansza_8cpp.html#abaa5abc4e2d9b1b8bd1cd70fa96844de", null ],
    [ "deleteBoard", "plansza_8cpp.html#ae91dd3ac3ca6c145fbdbcf82eab748f6", null ]
];